
<link rel="stylesheet" href="css/viewboard.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton+SC&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">

<?php
include "header.php";
ini_set("display_errors", "On");
require_once "database/boarddatabaseConnect.php";
$codeInput = filter_input(INPUT_POST, "code", FILTER_SANITIZE_NUMBER_INT);

// Prepare SQL statement
$query = "SELECT * FROM boards WHERE boardCode = :codeInput";
$statement = $pdo->prepare($query);

// Execute SQL statement
$statement->execute([':codeInput' => $codeInput]);

$found = $statement->rowCount();

$row = $statement->fetch();

if ($found > 0){
   echo "<h1>".$row["boardName"]."</h1>";
   echo "<h2>".$row["boardCode"]."</h2>";
   echo "<h2>".$row["boardDesc"]."</h2>";
   echo "<h2>Comments</h2>";
} else {
    echo "No Code Found";
}?>

