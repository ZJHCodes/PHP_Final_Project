<?php include "header.php"?>

<link rel="stylesheet" href="css/aboutPage.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton+SC&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">

<h1 id="about">About Us</h1>
<h2>This website is a place where you can collaborate with your friends to create a fun camping trip.
<br>    
Sometimes people don't have the time to get together and plan a trip. This website makes it possible for anyone to collaborate with a group and plan a trip in their own free time.</h2>