<?php

    if ($_SERVER["REQUEST_METHOD"] == "POST"){

        try{
        require_once "database/databaseConnect.php";
        $usernameInput = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
        $passwordInput = filter_input(INPUT_POST, "userpassword", FILTER_SANITIZE_SPECIAL_CHARS);
        
        $query = "INSERT INTO tb_user (username, userpassword)
                  VALUES (:username, :userpassword);";

        $statement = $pdo->prepare($query);
        $statement->bindValue(":username", $usernameInput);
        $statement->bindValue(":userpassword", $passwordInput);
        $statement->execute();

        header("Location:index.php");
        } catch(PDOException $e){
            die($e);
        }

    }else{
        header("index.php");
    }
?>
