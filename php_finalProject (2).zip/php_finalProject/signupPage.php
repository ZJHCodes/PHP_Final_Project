<link rel="stylesheet" href="css/signupPage.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
<?php include "header.php"; ?>

<div id="signupDiv">
<h1 id="signupHeader">Sign Up</h1>

<form action="signup.php" method="post">
    <label for="username">Username</label>
    <input name="username" type="text">
    <br>
    <br>
    <label for="password">Password</label>
    <input name="userpassword" type="password">
    <input type="submit">
</form>


</div>

<div id="info"><h1>Sign Up for the ability to view, create, and comment on boards. After creating an account click the login button to sign in.</h1></div>