<?php include "header.php";

?>
<link rel="stylesheet" href="css/indexPage.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
<?php
    echo "<h1>Welcome to Camp Collab</h1>";
    if (isset($_SESSION["username"])){
        echo "<h2 id=\"usernameDisplay\">".$_SESSION["username"];"</h2>";
        echo "<form action=\"logout.php\"><input type=\"submit\" value=\"Log Out\"></form>";
    }else{
        echo "<h1>To Get Started Create An account</h1>";
    }
    
?>


