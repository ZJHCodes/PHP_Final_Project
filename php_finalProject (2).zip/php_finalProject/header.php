<?php
$servername = "localhost";
$username = "root";
$password = "root";
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
try {
  $db = new PDO("mysql:host=$servername;dbname=campCollab", $username, $password);
  // set the PDO error mode to exception
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Error connecting to database";
}
?>

<link rel="stylesheet" href="css/styles.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton+SC&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Anton+SC&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">

<div class="nav">
    <img id="logo" src="images/campCollabLogo.png">
<ul id="mainNav">
    <li><a href="index.php">Home</a></li>
    <li><a href="boardPage.php">Boards</a></li>
    <li><a href="about.php">About</a></li>
    
</ul>


     <ul id="signupAndlogin">
        <li id="signup"><a href="signupPage.php">Sign-Up</a></li>
        <li id="login"><a href="loginPage.php">Login</a></li>
    </ul>



   
</div>