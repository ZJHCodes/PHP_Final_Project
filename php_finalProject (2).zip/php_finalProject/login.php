<?php
session_start();
    if ($_SERVER["REQUEST_METHOD"] == "POST"){

        try{
        
        require_once "database/databaseConnect.php";
        $usernameInput = trim(filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS));
        $passwordInput = trim(filter_input(INPUT_POST, "userpassword", FILTER_SANITIZE_SPECIAL_CHARS));
        
        
        
        if(empty($usernameInput) || empty($passwordInput)){
            echo "PLEASE INSERT PASSWORD AND USERNAME";
            echo $usernameInput;
            echo $passwordInput;
        } else{
            $query = "SELECT * FROM `tb_user` WHERE `username` = :username AND `userpassword` = :password limit 1;";
            $statement = $pdo->prepare($query);
            $statement->execute(
                array(
                    ":username" => $usernameInput,
                    ":password" => $passwordInput
                )
            );
        }
        $found = $statement->rowCount();

        if ($found > 0){
            
            $_SESSION["username"] = $usernameInput;
            header("Location:index.php");
        }else{
            include "header.php";
            echo "<h1>Incorrect Password Or Username Please Try Again</h1>";
        }

        } catch(PDOException $e){
            die($e);
        }

    }else{
        header("index.php");
    }
?>