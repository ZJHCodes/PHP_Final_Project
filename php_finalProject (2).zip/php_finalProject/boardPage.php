<?php
    include "header.php";

 if (isset($_SESSION["username"])){
    echo "<h1><a href=\"addboardPage.php\">Add Board +</a></h1>";
    echo "<form action=\"getBoard.php\" method=\"post\">";
    echo "<input type=\"text\" id=\"code\" name=\"code\">";
    echo "<input type=\"submit\">";
    echo "</form>";
    }else{
        echo "<h1>Sign Up and Log In to Create Boards</h1>";
    }

?>