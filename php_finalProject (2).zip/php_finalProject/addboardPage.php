

<?php
    include "header.php";
?>

<link rel="stylesheet" href="css/addboardPage.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">

<form method="post" action="addBoard.php">
    <label class="inputDesc" for="boardname">Board Name:</label>
    <input name="boardname" type="text">
    <label class="inputDesc" for="boardcode">Board Code:</label>
    <input name="boardcode" type="text">
    <label class="inputDesc" for="boardcode">Description:</label>
    <input name="descriptionInput" type="text">
    <h2>////////////////////////////////////////////////////////////////////////////////////////////Project was more complicated than I expected so these below don't do anything////////////////////////////////////////////////////////////////////////</h2>
    <label class="inputDesc" for="boardcode">Date:</label>
    <input name="dateInput" type="text">
    <label class="inputDesc" for="boardcode">Time:</label>
    <input name="timeInput" type="text">
    <input id="submit" type="submit">
</form>