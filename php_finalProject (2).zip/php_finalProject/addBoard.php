<?php
require_once "database/boarddatabaseConnect.php";
$boardnameInput = filter_input(INPUT_POST, "boardname", FILTER_SANITIZE_SPECIAL_CHARS);
$boardcodeInput = filter_input(INPUT_POST, "boardcode", FILTER_SANITIZE_SPECIAL_CHARS);
$desc = filter_input(INPUT_POST, "descriptionInput", FILTER_SANITIZE_SPECIAL_CHARS);


if ($_SERVER["REQUEST_METHOD"] == "POST"){
    try{

    
    $query = "INSERT INTO boards (boardname, boardcode, boardDesc)
          VALUES (:boardname, :boardcode, :descInput);";

$statement = $pdo->prepare($query);
$statement->bindValue(":boardname", $boardnameInput);
$statement->bindValue(":boardcode", $boardcodeInput);
$statement->bindValue(":descInput", $desc);
$statement->execute();
header("Location: boardPage.php");
} catch(PDOException $e){
    die($e);
}
}


?>