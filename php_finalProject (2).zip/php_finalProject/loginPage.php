<link rel="stylesheet" href="css/loginPage.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
<?php include "header.php"; ?>

<div id="loginDiv">
<h1 id="loginHeader">Log In</h1>

<form method="post" action="login.php">
    <label for="username">Username</label>
    <input name="username" type="text">
    <br>
    <br>
    <label for="password">Password</label>
    <input name="userpassword" type="password">
    <input type="submit">
</form>


</div>

<div id="info"><h1>Log In for the ability to view, create, and comment on boards. Please do not use bad language or statements in your username or board comments.</h1></div>